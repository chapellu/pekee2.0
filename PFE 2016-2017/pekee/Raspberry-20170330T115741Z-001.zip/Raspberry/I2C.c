#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>

#include "I2C.h"

//buffer utilise pour les erreurs
const char *buffer;

//structure de donnees pour recuperer la taille des donnees envoyees.
struct Data
{
	int size;
	char data[5];
	
};

//Initialisation du bus I2C    
int InitI2C(char filename[], int addr)
{
	int file=0;
	if ((file = open(filename, O_RDWR)) < 0) { //ouverture du bus I2C
		/* ERROR HANDLING: you can check errno to see what went wrong */
		perror("Failed to open the i2c bus");
		exit(1);
	}
	 
	if (ioctl(file,I2C_SLAVE,addr) < 0) { //on definie l'adresse de l'esclave
        printf("Failed to acquire bus access and/or talk to slave.\n");
        /* ERROR HANDLING; you can check errno to see what went wrong */
        exit(1);
    }
    return file;
}

//Permet d'envoyer des donnees a l'esclave
int WriteData(int file, Data buf)
{
	if (write(file,buf.data,buf.size) != buf.size) { //ecrit sur file les donnees passees d'une certaine taille
        /* ERROR HANDLING: i2c transaction failed */
        printf("Failed to write to the i2c bus.\n");
        buffer = strerror(errno);
        printf(buffer);
        printf("\n\n");
        return -1;
	}else{
		return 0;
	}
}

//Permet de lire les donnees envoyees par l'esclave
int ReadData(int file)
{
	char data[1]={0};
	if (read(file,data,1) != 1) { //lit les donnees presentes sur file
		/* ERROR HANDLING: i2c transaction failed */
		printf("Failed to read from the i2c bus.\n");
		buffer = strerror(errno);
		printf(buffer);
		printf("\n\n");
		return -1;
	} else {
		return (int)data[0];
	}
}

//Cette fonction permet d'attendre le retour de l'Arduino lorsqu'un cas est termine
void Wait(int file)
{
	while(ReadData(file) == 0){
		sleep(1);
	}
}

//Definition des fonctions pour les mouvements du robot
//size permet de savoir combien de donnees sont a envoye a l'Arduino
//les data dans l'ordre comme definis sur l'Arduino

//Ligne droite sur une certaine distance
void StraightLine(int file, int distance)
{
	Data buf;
	buf.size=2;
	buf.data[0]=1;
	buf.data[1]=distance;
	WriteData(file, buf);
	Wait(file);
}

//Virage d'un certain angle dans une direction
void Turn(int file, int angle, int direction)
{
	Data buf;
	buf.size=3;
	buf.data[0]=2;
	buf.data[1]=angle;
	buf.data[2]=direction;
	WriteData(file, buf);
	Wait(file);
}

//Realise une ligne droite (dist1) puis une virage (angle, direction), suivi d'une autre ligne droite (dist2)
void MakeL(int file, int dist1, int angle, int direction , int dist2)
{
	Data buf;
	buf.size=5;
	buf.data[0]=3;
	buf.data[1]=dist1;	
	buf.data[2]=angle;
	buf.data[3]=direction;
	buf.data[4]=dist2;
	WriteData(file, buf);
	Wait(file);
}

//Realsie un aller-retour sur une distance, on choisi la direction du virage	
void RoundTrip(int file, int distance, int direction)
{
	Data buf;
	buf.size=3;
	buf.data[0]=4;
	buf.data[1]=distance;
	buf.data[2]=direction;
	WriteData(file, buf);
	Wait(file);
}

//Realise un triangle, parcours le premier cote (dist1), puis un virage (angle, direction), suivi du second cote (dist1). L'arduino calcul l'angle et le cote restant pour revenir a la position initiale
void MakeTriangle(int file, int dist1, int angle, int direction , int dist2)
{
	Data buf;
	buf.size=5;
	buf.data[0]=5;
	buf.data[1]=dist1;	
	buf.data[2]=angle;
	buf.data[3]=direction;
	buf.data[4]=dist2;
	WriteData(file, buf);
	Wait(file);
}

//Realise un rectangle, parcours le premier cote (dist1), puis fait un virage selon la direction, suivi du second cote (dist2). Cette procedure est repetee une seconde fois apres un autre virage
void Rectangle(int file, int dist1, int direction, int dist2)
{
	Data buf;
	buf.size=4;
	buf.data[0]=6;
	buf.data[1]=dist1;
	buf.data[2]=direction;
	buf.data[3]=dist2;
	WriteData(file, buf);
	Wait(file);
}
