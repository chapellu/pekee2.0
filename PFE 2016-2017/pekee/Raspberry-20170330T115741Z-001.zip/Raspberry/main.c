#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>

#include "I2C.h"

int main(void) {
	int file=0;
    char filename[40]={0};

    int addr = 0x12;        // The I2C address of the Arduino

    sprintf(filename,"/dev/i2c-1");	//On defini le nom du device utilise pour l'I2C
    
	if((file=InitI2C(filename, addr))<0)
	{
		exit(1);
	}

	StraightLine(file, 50);
    
	close(file);
    return 0;
}
