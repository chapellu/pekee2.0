#ifndef I2C_H_INCLUDED
#define I2C_H_INCLUDED

#define LEFT 0
#define RIGHT 1

typedef struct Data Data;

int InitI2C(char filename[], int addr);
int WriteData(int file, Data buf);
int ReadData(int file);
void Wait(int file);
void StraightLine(int file, int distance);
void Turn(int file, int angle, int direction);
void MakeL(int file, int dist1, int angle, int direction, int dist2);
void RoundTrip(int file, int distance, int direction); 
void MakeTriangle(int file, int dist1, int angle, int direction , int dist2);
void Rectangle(int file, int dist1, int direction, int dist2);

#endif // I2C_H_INCLUDED
